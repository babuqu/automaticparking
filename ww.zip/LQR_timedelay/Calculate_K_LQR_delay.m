function [table_k_delay,state_num_delay_model] = Calculate_K_LQR_delay(vehicle_parameters,control_parameters,speed,Q1,Q2,Q3,Q4)
%%
tua = control_parameters.T_filter_delta;%һ�ڹ���
pure_delay = control_parameters.T_steer_pure_delay;%���ӳ�
Ts = vehicle_parameters.ts;
state_num_delay_model = 5+int8(pure_delay/Ts);
table_k_delay = zeros(2,length(speed),state_num_delay_model );%��ʼ��һ��3ά����
R =800;
%%
for i=1:1:length(vehicle_parameters.mass)
    temp_mass = vehicle_parameters.mass(i);
    temp_iz=vehicle_parameters.iz(i);
    
    for j=1:1:length(speed)
        temp_q.q1=Q1(i,j);
        temp_q.q2=Q2(i,j);
        temp_q.q3=Q3(i,j);
        temp_q.q4=Q4(i,j);
        [Ac,Bc,Ec]=Matrix_calculate(temp_mass,temp_iz,speed(j),vehicle_parameters);
        [G_ss_delay,A_bar,B_bar,matrix_a,matrix_b] = get_delay_system(Ac,Bc,Ec,tua,pure_delay,Ts);
        Q = zeros(size(G_ss_delay.A));
        Q(1:4,1:4) = diag([temp_q.q1 temp_q.q2 temp_q.q3 temp_q.q4]);
        [X,K,L,info]= idare(matrix_a,matrix_b,Q,R,[],[]);
        table_k_delay(i,j,:) = K;
    end
end
% 
end


function [Ac,Bc,Ec]=Matrix_calculate(mass,iz,speed,vehicle_parameters)
    cf=interp1(vehicle_parameters.mass,vehicle_parameters.cf,mass,'linear');
    cr=interp1(vehicle_parameters.mass,vehicle_parameters.cr,mass,'linear');
    lr=interp1(vehicle_parameters.mass,vehicle_parameters.lr,mass,'linear');
    lf=interp1(vehicle_parameters.mass,vehicle_parameters.lf,mass,'linear');
    Ac=[0.0,   1.0,                        0.0,                0.0;
        0.0,   -(cf+cr)/mass/speed ,      (cf+cr)/mass,       (lr*cr-lf*cf)/mass/speed ;
        0.0,   0.0,                        0.0,                1.0;
        0.0,   (lr*cr-lf*cf)/iz/speed,    (lf*cf-lr*cr)/iz,   -(lf*lf*cf+lr*lr*cr)/iz/speed];
    Bc=[0.0;   cf/mass;                    0.0 ;               lf*cf/iz];
    Ec=zeros(4, 1);
    Ec(2,1) = -( cf * lf -  cr * lr) / (mass) - speed*speed;
    Ec(4,1) = -( cf * lf * lf +  cr * lr * lr) / (iz);
end
%û������
function [G_ss_delay,A_bar,B_bar,matrix_a,matrix_b] = get_delay_system(Ac,Bc,E,tua,pure_delay,Ts)
    delay_window = int8(pure_delay/Ts);
    A_bar= [     Ac             Bc
            zeros(1,length(Ac)) -1/tua];
    B_bar = [zeros(length(Bc),1)
             1/tua];
    E_bar = [E
             0];
         
   % A_bar = eye(size(A_bar))+A_bar*Ts;
    A_bar = inv( eye(size(A_bar))-Ts*0.5*A_bar)*( eye(size(A_bar))+Ts*0.5*A_bar);
    B_bar = B_bar*Ts;
    E_bar = E*Ts;
    if delay_window==0
        matrix_a = A_bar;
        matrix_b = B_bar;
        G_ss_delay = ss(matrix_a, matrix_b, eye(size(matrix_a)),[],Ts);% creates the discrete-time model
    else
        matrix_a = [A_bar B_bar zeros(length(A_bar),delay_window-1)
                 zeros(delay_window,length(A_bar)+delay_window)];
        for i = 1:delay_window-1
            matrix_a(length(A_bar)+i,length(A_bar)+i+1) = 1;
        end
        matrix_b = zeros(length(matrix_a),1);
        matrix_b(end,1) = 1;
        G_ss_delay = ss(matrix_a, matrix_b, eye(size(matrix_a)),[],Ts);
    end
end