function [K] = Calculate_K_LQR(control_parameters,vehicle_parameters,v,fr,k,Q1,Q2,Q3,Q4)
%%
%K=zeros(4,4);%�����ʼ��
tua = control_parameters.T_filter_delta;%һ�ڹ���
pure_delay = control_parameters.T_steer_pure_delay;%���ӳ�
Ts = vehicle_parameters.ts;
R =[300 0;0 800];
%R =800;
%%
        [Ac,Bc1,Bc2]=Matrix_calculate(v,vehicle_parameters,fr,k);
        [G_ss_delay,A_bar,B_bar,matrix_a,matrix_b] = get_delay_system(Ac,Bc1,Bc2,tua,pure_delay,Ts);
        temp_q.q1=Q1(1,1);
        temp_q.q2=Q2(1,1);
        temp_q.q3=Q3(1,1);
        temp_q.q4=Q4(1,1);
        Q = zeros(size(G_ss_delay.A));
        Q(1:4,1:4) = diag([temp_q.q1 temp_q.q2 temp_q.q3 temp_q.q4]);
        [X,K,L,info]= idare(matrix_a,matrix_b,Q,R,[],[]);

end

%%
%%LQR


function [Ac,Bc1,Bc2]=Matrix_calculate(v,vehicle_parameters,fr,k)%��������
    %cf=interp1(speed,vehicle_parameters.cf,mass,'linear');%interp1�������㣬����ֵ����ֵ�㣩
    %m=[1,2];n=[3,4];interp1(m,n,1.8,'liner')��ֵ����
    L=vehicle_parameters.L;
    %v=speed;
    %k=0.02;
    der=atan(L*k);
    Ac=[0.0,   0.0,       cos(fr)             -v*sin(fr);
        0.0,   0.0,       sin(fr),            v*cos(fr);
        0.0,   0.0,        0.0,               0.0;
        0.0,   0.0,        tan(der)/L,        0.0];
    Bc1=[0.0 ;  0.0 ; 1.0 ;0.0];
    Bc2=[ 0.0; 0.0 ; 0.0; v/L/cos(der)/cos(der)];
end

function [G_ss_delay,A_bar,B_bar,matrix_a,matrix_b] = get_delay_system(Ac,Bc1,Bc2,tua,pure_delay,Ts)
    delay_window = int8(pure_delay/Ts);
    A_bar= [     Ac             Bc2
            zeros(1,length(Ac))  -1/tua];%ac=3*ones(4,4);bc=2*ones(4,2);cc=2*ones(2,5);dc=0*ones(2,1); A_bar=[ac,bc;cc,dc]
    B_bar = [Bc1 zeros(length(Bc1),1)
             0 1/tua];

         
    A_bar = eye(size(A_bar))+A_bar*Ts;
    %A_bar = inv(eye(size(A_bar))-Ts*0.5*A_bar)*( eye(size(A_bar))+Ts*0.5*A_bar);
    %A_bar = (eye(size(A_bar))-Ts*0.5*A_bar)*inv(eye(size(A_bar))+Ts*0.5*A_bar);
    B_bar = B_bar*Ts;
    if delay_window==0
        matrix_a = A_bar;
        matrix_b = B_bar;
        G_ss_delay = ss(matrix_a, matrix_b, eye(size(matrix_a)),[],Ts);% creates the discrete-time model
    else%
        B_bar1=B_bar(:,1);
        B_bar2=B_bar(:,2);
        matrix_a = [A_bar B_bar2 zeros(length(A_bar),delay_window-1)
                 zeros(delay_window,length(A_bar)+delay_window)];
        for i = 1:delay_window-1
            matrix_a(length(A_bar)+i,length(A_bar)+i+1) = 1;
        end
        matrix_b = zeros(length(matrix_a),2);
        matrix_b(1:length(B_bar1),1) = B_bar1;
        matrix_b(end,2) = 1;
        G_ss_delay = ss(matrix_a, matrix_b, eye(size(matrix_a)),[],Ts);
    end
end