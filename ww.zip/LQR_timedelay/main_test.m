%%
clc
close all
clear all
address = 'E:\matlabfile\�Զ�����\Copy_of_1.3���������ܱ仯����Ӧ\simulink_ww\';
cd(address)
%%
[vehicle_parameters,control_parameters,speed,Q1,Q2,Q3,Q4] = InitialParameters();%���г�ʼ������
N=int8(control_parameters.T_steer_pure_delay/vehicle_parameters.ts);
num=20;
table1=zeros(2,5+N,num,num);
%table1=cell(100,100);
for i=1:num
%i=1
fr=2*pi/num*i;%�Ƕ�
    for j=1:num
        k=-vehicle_parameters.kmax+2*vehicle_parameters.kmax/num*j;%����
        for z=1:2
            if z==1
                v=speed(1);
            else
                v=-speed(1);
            end
            K = Calculate_K_LQR(control_parameters,vehicle_parameters,v,fr,k,Q1,Q2,Q3,Q4);%����LQR��K����
            table1(:,:,i,j,z)=K;
        end
        
    end
%table2(i)=fr;
end%
%%%
sim("car_model_test1_20220617.slx");
%%
out=ans.simout;
xr=out(:,1);x=out(:,3);
yr=out(:,2);y=out(:,4);
theta=out(:,5);
head_x=x+vehicle_parameters.L*cos(theta);
head_y=y+vehicle_parameters.L*sin(theta);
%%
figure(1)
plot(xr,yr,x,y,head_x,head_y,'linewidth',3)
legend("Desired trajectory","Actual trajectory","Head Actual trajectory");
%
pic_num =  1;
f=figure(2);
for i=1:20:length(xr)
    plot(xr,yr,'red');
    axis([-10,20,-20,20]); %x,y��ķ�Χ
    hold on;
    %plot([head_x(i),head_y(i)],[x(i),y(i)])
    line([head_x(i),x(i)],[head_y(i),y(i)]);
    axis([-10,20,-20,20]); %x,y��ķ�Χ
    pause(0.05);
    %
    F=getframe(gcf);
    I=frame2im(F);
    [I,map]=rgb2ind(I,256);
    if pic_num == 1
        imwrite(I,map,'test2.gif','gif','Loopcount',inf,'DelayTime',0.2);
    else
        imwrite(I,map,'test2.gif','gif','WriteMode','append','DelayTime',0.2);
    end
    pic_num = pic_num + 1;
    %
    hold off;
    %hold on
end
% figure(3)
% for i=1:40:length(xr)
%     plot(xr,yr,'red');
%     legend("Desired trajectory");
%     axis([-10,20,-30,30]); %x,y��ķ�Χ
%     
%     hold on;
%     %plot([head_x(i),head_y(i)],[x(i),y(i)])
%     line([head_x(i),x(i)],[head_y(i),y(i)]);
%     legend("Actual trajectory");
%     xlabel('x/m');
%     ylabel('y/m');
%     hold on;
% end